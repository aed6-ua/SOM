IMPORTANTE seguir las instrucciones:
Ejecutar el programa cuando se tenga tiempo ya que habrá que dejarlo correr durante un buen rato,
idealmente sin utilizar el ordenador mientras tanto.
Puede tardar media hora o más en terminar.


1. Tener tarjeta gráfica NVIDIA
2. Ejecutar el script run.bat
3. Esperar.
4. Ver los resultados.txt


El programa terminará cuando desaparezca la ventana de CMD.